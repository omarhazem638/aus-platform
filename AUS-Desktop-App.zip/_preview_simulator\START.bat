@echo off
title AUS — AI University Simulator
echo.
echo  ╔═══════════════════════════════════════╗
echo  ║   AUS — AI University Simulator       ║
echo  ║   منصة القيادة الذكية                 ║
echo  ╚═══════════════════════════════════════╝
echo.
echo  جاري تشغيل المحاكي...
echo  Opening AUS Simulator...
echo.

:: Try Python 3
python -m http.server 5180 --directory "%~dp0" >nul 2>&1 &
timeout /t 2 /nobreak >nul
start http://localhost:5180/index.html

echo  ✅ تم فتح المحاكي في المتصفح
echo  ✅ Simulator opened in browser
echo.
echo  لإيقاف التشغيل: أغلق هذه النافذة
echo  To stop: close this window
echo.
pause
