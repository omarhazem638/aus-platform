// =============================================================================
// aus_37_cert_ui.js  —  Certification System: exam engine + all rendering
// Depends on window._AUS_CERT_CORE (defined in aus_36_certification.js)
// =============================================================================

(function () {
'use strict';

var C = window._AUS_CERT_CORE;
if (!C) { console.error('[AUS Cert] core module missing — aus_36_certification.js must load first'); return; }

// ── Attempt persistence (anti-cheat: timer survives refresh) ────────────────
var STALE_MS = 2 * 60 * 60 * 1000; // an attempt older than 2h is treated as abandoned

function attemptKey(id) { return C.ATTEMPT_KEY_PREFIX + id; }
function loadAttempt(id) {
    try {
        var raw = localStorage.getItem(attemptKey(id));
        if (!raw) return null;
        var a = JSON.parse(raw);
        if (!a || a.finished || (Date.now() - a.createdTs) > STALE_MS) return null;
        return a;
    } catch (e) { return null; }
}
function saveAttempt(a) { try { localStorage.setItem(attemptKey(a.id), JSON.stringify(a)); } catch (e) {} }
function clearAttempt(id) { try { localStorage.removeItem(attemptKey(id)); } catch (e) {} }

function createAttempt(type, specId, toolIdx, questions) {
    var id = C.certId(type, specId, toolIdx);
    var a = {
        id: id, type: type, specId: specId, toolIdx: toolIdx,
        questions: questions, answers: new Array(questions.length).fill(null),
        idx: 0, qStartTs: Date.now(), createdTs: Date.now(), finished: false
    };
    saveAttempt(a);
    return a;
}

// ── Scoring ──────────────────────────────────────────────────────────────────
function isAnswerCorrect(q, answer) {
    if (answer === null || answer === undefined) return false;
    if (q.qType === 'mcq') return answer === q.correctIndex;
    if (q.qType === 'order') {
        if (!Array.isArray(answer) || answer.length !== q.items.length) return false;
        var seq = answer.map(function (i) { return q.items[i]; });
        return JSON.stringify(seq) === JSON.stringify(q.correctOrder);
    }
    if (q.qType === 'match') {
        if (!Array.isArray(answer) || answer.length !== q.left.length) return false;
        for (var i = 0; i < answer.length; i++) {
            if (answer[i] === null || answer[i] === undefined) return false;
            if (q.right[answer[i]] !== q.correctPairs[i]) return false;
        }
        return true;
    }
    return false;
}
function scoreAttempt(attempt) {
    var correct = 0;
    attempt.questions.forEach(function (q, i) { if (isAnswerCorrect(q, attempt.answers[i])) correct++; });
    var total = attempt.questions.length;
    var percent = total ? Math.round((correct / total) * 100) : 0;
    var cfg = C.CERT_CONFIG[attempt.type];
    return { correct: correct, total: total, percent: percent, passed: percent >= cfg.passPercent };
}

// ── Timer-driven exam runner ─────────────────────────────────────────────────
var _timerHandle = null;
var _pendingMatch = { leftSel: null, pairs: [] };   // transient UI state for the current match question
var _pendingOrder = [];                              // transient UI state for the current order question

function stopTimer() { if (_timerHandle) { clearInterval(_timerHandle); _timerHandle = null; } }

function startExam(type, specId, toolIdx) {
    var id = C.certId(type, specId, toolIdx);
    var existing = loadAttempt(id);
    if (existing) { _renderExamQuestion(existing); return; }

    var tool = C.getTool(specId, toolIdx);
    var siblings = C.getSiblingTools(specId, toolIdx);
    var cfg = C.CERT_CONFIG[type];
    _renderExamLoading(tool, cfg);

    C.generateExamQuestions(tool, siblings, type, cfg.questions, function (questions) {
        var attempt = createAttempt(type, specId, toolIdx, questions);
        _renderExamQuestion(attempt);
    });
}
window.certStartExam = startExam;

function _renderExamLoading(tool, cfg) {
    var el = document.getElementById('vocab') || document.getElementById('toolQuizArea');
    var host = document.getElementById('certHost') || el;
    if (!host) return;
    host.innerHTML =
    '<div class="cert-wrap"><div class="cert-card" style="text-align:center;padding:60px 30px;">' +
        '<div class="cert-spin"><i class="fas fa-circle-notch fa-spin"></i></div>' +
        '<h3 style="color:#d4af37;margin-top:18px;">جارٍ تحضير أسئلة ' + cfg.label + '...</h3>' +
        '<p style="color:rgba(255,255,255,0.45);font-size:0.85rem;margin-top:8px;">يقوم الذكاء الاصطناعي بإعداد ' + cfg.questions + ' سؤالاً مخصصاً لأداة ' + tool.name + '</p>' +
    '</div></div>';
}

function _advance(attempt, answerValue) {
    attempt.answers[attempt.idx] = answerValue;
    if (attempt.idx + 1 >= attempt.questions.length) {
        attempt.finished = true;
        saveAttempt(attempt);
        stopTimer();
        _finishExam(attempt);
        return;
    }
    attempt.idx += 1;
    attempt.qStartTs = Date.now();
    saveAttempt(attempt);
    _pendingMatch = { leftSel: null, pairs: new Array(attempt.questions[attempt.idx].qType === 'match' ? attempt.questions[attempt.idx].left.length : 0).fill(null) };
    _pendingOrder = [];
    _renderExamQuestion(attempt);
}

function _finishExam(attempt) {
    var result = scoreAttempt(attempt);
    var tool = C.getTool(attempt.specId, attempt.toolIdx);
    result.type = attempt.type; result.specId = attempt.specId; result.toolIdx = attempt.toolIdx;
    result.ts = Date.now();
    C.saveResult(attempt.id, result);
    clearAttempt(attempt.id);
    if (window._AUS_BUS) window._AUS_BUS.emit('XP_AWARDED', { amount: result.passed ? 60 : 10, source: 'cert_exam_' + attempt.type });
    _renderExamResults(result, tool);
}

function _certHost() {
    return document.getElementById('certHost');
}

function _renderExamQuestion(attempt) {
    var host = _certHost();
    if (!host) return;
    _activeAttempt = attempt;
    stopTimer();
    var q = attempt.questions[attempt.idx];
    var cfg = C.CERT_CONFIG[attempt.type];
    var tool = C.getTool(attempt.specId, attempt.toolIdx);
    if (q.qType === 'match' && (!_pendingMatch.pairs || _pendingMatch.pairs.length !== q.left.length)) {
        _pendingMatch = { leftSel: null, pairs: new Array(q.left.length).fill(null) };
    }
    if (q.qType === 'order' && _pendingOrder.length === 0) _pendingOrder = [];

    var progressPct = Math.round((attempt.idx / attempt.questions.length) * 100);
    var body = q.qType === 'mcq' ? _mcqHtml(q) : q.qType === 'order' ? _orderHtml(q) : _matchHtml(q);

    host.innerHTML =
    '<div class="cert-wrap">' +
        '<div class="cert-exam-top">' +
            '<span class="cert-exam-badge">' + cfg.icon + ' ' + cfg.label + ' — ' + tool.name + '</span>' +
            '<span class="cert-exam-count">' + (attempt.idx + 1) + ' / ' + attempt.questions.length + '</span>' +
        '</div>' +
        '<div class="cert-progress-track"><i style="width:' + progressPct + '%"></i></div>' +
        '<div class="cert-timer-row">' +
            '<div class="cert-timer-ring" id="certTimerRing"><span id="certTimerNum">' + cfg.seconds + '</span></div>' +
            '<div class="cert-timer-bar-track"><i id="certTimerBar" style="width:100%"></i></div>' +
        '</div>' +
        '<div class="cert-card">' + body + '</div>' +
    '</div>';

    var startTs = attempt.qStartTs;
    var seconds = cfg.seconds;
    _timerHandle = setInterval(function () {
        var remaining = Math.max(0, seconds - (Date.now() - startTs) / 1000);
        var pct = Math.max(0, (remaining / seconds) * 100);
        var numEl = document.getElementById('certTimerNum');
        var barEl = document.getElementById('certTimerBar');
        if (numEl) numEl.textContent = Math.ceil(remaining);
        if (barEl) barEl.style.width = pct + '%';
        if (remaining <= 5 && numEl) numEl.parentElement.classList.add('urgent');
        if (remaining <= 0) {
            stopTimer();
            var currentAnswer = q.qType === 'mcq' ? null : q.qType === 'order' ? _pendingOrder.slice() : _pendingMatch.pairs.slice();
            _advance(attempt, (q.qType !== 'mcq' && currentAnswer.some(function(v){return v!==null && v!==undefined;})) ? currentAnswer : null);
        }
    }, 200);
}

function _mcqHtml(q) {
    return '' +
    '<p class="cert-q-prompt">' + q.prompt + '</p>' +
    '<div class="cert-q-opts">' + q.options.map(function (o, i) {
        return '<button class="cert-opt" onclick="window._certAnswerMcq(' + i + ')">' +
            '<span class="cert-opt-badge">' + String.fromCharCode(65 + i) + '</span>' + o + '</button>';
    }).join('') + '</div>';
}
function _orderHtml(q) {
    var chips = q.items.map(function (item, i) {
        var pos = _pendingOrder.indexOf(i);
        return '<button class="cert-order-chip' + (pos !== -1 ? ' picked' : '') + '" data-i="' + i + '" onclick="window._certPickOrder(' + i + ')">' +
            (pos !== -1 ? '<span class="cert-order-num">' + (pos + 1) + '</span>' : '') + item + '</button>';
    }).join('');
    return '' +
    '<p class="cert-q-prompt">' + q.prompt + '</p>' +
    '<p class="cert-hint">اضغط العناصر بالترتيب الصحيح من الأول إلى الأخير.</p>' +
    '<div class="cert-order-list">' + chips + '</div>' +
    '<button class="cert-submit-btn" id="certOrderSubmit" ' + (_pendingOrder.length === q.items.length ? '' : 'disabled') + ' onclick="window._certSubmitOrder()">تأكيد الترتيب</button>';
}
function _matchHtml(q) {
    var leftHtml = q.left.map(function (l, i) {
        var matched = _pendingMatch.pairs[i] !== null && _pendingMatch.pairs[i] !== undefined;
        return '<button class="cert-match-item' + (matched ? ' matched' : (_pendingMatch.leftSel === i ? ' selected' : '')) + '" onclick="window._certPickLeft(' + i + ')" ' + (matched ? 'disabled' : '') + '>' +
            (matched ? '<span class="cert-order-num">' + (i + 1) + '</span>' : '') + l + '</button>';
    }).join('');
    var usedRight = _pendingMatch.pairs.filter(function (v) { return v !== null && v !== undefined; });
    var rightHtml = q.right.map(function (r, i) {
        var used = usedRight.indexOf(i) !== -1;
        return '<button class="cert-match-item right' + (used ? ' matched' : '') + '" onclick="window._certPickRight(' + i + ')" ' + (used ? 'disabled' : '') + '>' + r + '</button>';
    }).join('');
    var allMatched = _pendingMatch.pairs.every(function (v) { return v !== null && v !== undefined; });
    return '' +
    '<p class="cert-q-prompt">' + q.prompt + '</p>' +
    '<p class="cert-hint">اختر عنصراً من اليمين ثم عرّفه المطابق من اليسار.</p>' +
    '<div class="cert-match-cols"><div class="cert-match-col">' + leftHtml + '</div><div class="cert-match-col">' + rightHtml + '</div></div>' +
    '<button class="cert-submit-btn" id="certMatchSubmit" ' + (allMatched ? '' : 'disabled') + ' onclick="window._certSubmitMatch()">تأكيد المطابقة</button>';
}

var _activeAttempt = null;
function _currentAttempt() { return _activeAttempt; }

window._certAnswerMcq = function (idx) {
    var a = _currentAttempt(); if (!a) return;
    stopTimer();
    _advance(a, idx);
};
window._certPickOrder = function (i) {
    var pos = _pendingOrder.indexOf(i);
    if (pos !== -1) { _pendingOrder.splice(pos, 1); } else { _pendingOrder.push(i); }
    _renderExamQuestion(_currentAttempt());
};
window._certSubmitOrder = function () {
    var a = _currentAttempt(); if (!a) return;
    stopTimer();
    _advance(a, _pendingOrder.slice());
};
window._certPickLeft = function (i) { _pendingMatch.leftSel = i; _renderExamQuestion(_currentAttempt()); };
window._certPickRight = function (ri) {
    if (_pendingMatch.leftSel === null || _pendingMatch.leftSel === undefined) return;
    _pendingMatch.pairs[_pendingMatch.leftSel] = ri;
    _pendingMatch.leftSel = null;
    _renderExamQuestion(_currentAttempt());
};
window._certSubmitMatch = function () {
    var a = _currentAttempt(); if (!a) return;
    stopTimer();
    _advance(a, _pendingMatch.pairs.slice());
};

// =============================================================================
// RESULTS SCREEN — pass/fail messaging, certificate request, printable result
// =============================================================================
function _renderExamResults(result, tool) {
    var host = _certHost();
    if (!host) return;
    var cfg = C.CERT_CONFIG[result.type];

    if (result.passed) {
        host.innerHTML =
        '<div class="cert-wrap"><div class="cert-card cert-result pass">' +
            '<div class="cert-result-icon">🎉</div>' +
            '<div class="cert-result-pct">' + result.percent + '%</div>' +
            '<h2 class="cert-result-title">' + cfg.passMsg + '</h2>' +
            '<p class="cert-result-sub">' + result.correct + ' إجابة صحيحة من أصل ' + result.total + '</p>' +
            '<div class="cert-official-box">' +
                '<i class="fas fa-stamp"></i>' +
                '<p>لقد اجتزت الاختبار بنجاح.<br>يمكنك الحصول على الشهادة الرسمية من الجامعة من خلال مراجعة قسم الريادة والابتكار لإكمال إجراءات إصدار الشهادة.</p>' +
            '</div>' +
            '<div class="cert-result-actions">' +
                '<button class="cert-btn-gold" onclick="window._certRequestCertificate(\'' + result.type + '\',\'' + result.specId + '\',' + result.toolIdx + ')"><i class="fas fa-certificate"></i> طلب الشهادة</button>' +
                '<button class="cert-btn-outline" onclick="window._certPrintResult(\'' + result.type + '\',\'' + result.specId + '\',' + result.toolIdx + ')"><i class="fas fa-print"></i> طباعة النتيجة</button>' +
                '<button class="cert-btn-ghost" onclick="window.openCertifications(\'' + result.specId + '\',' + result.toolIdx + ')"><i class="fas fa-arrow-right"></i> رجوع للشهادات</button>' +
            '</div>' +
            '<div id="certRequestMsg"></div>' +
        '</div></div>';
    } else {
        host.innerHTML =
        '<div class="cert-wrap"><div class="cert-card cert-result fail">' +
            '<div class="cert-result-icon">📚</div>' +
            '<div class="cert-result-pct">' + result.percent + '%</div>' +
            '<h2 class="cert-result-title">حظاً أوفر</h2>' +
            '<p class="cert-result-sub">' + cfg.failMsg + '</p>' +
            '<p class="cert-result-detail">' + result.correct + ' إجابة صحيحة من أصل ' + result.total + ' — النسبة المطلوبة للنجاح ' + cfg.passPercent + '%</p>' +
            '<div class="cert-result-actions">' +
                '<button class="cert-btn-gold" onclick="window.openCertLearnPage(\'' + result.type + '\',\'' + result.specId + '\',' + result.toolIdx + ')"><i class="fas fa-book-open"></i> مراجعة المحتوى التعليمي</button>' +
                '<button class="cert-btn-ghost" onclick="window.openCertifications(\'' + result.specId + '\',' + result.toolIdx + ')"><i class="fas fa-arrow-right"></i> رجوع للشهادات</button>' +
            '</div>' +
        '</div></div>';
    }
}

window._certRequestCertificate = function (type, specId, toolIdx) {
    var tool = C.getTool(specId, toolIdx);
    var spec = C.getSpecialty(specId);
    var cfg = C.CERT_CONFIG[type];
    var req = {
        id: C.certId(type, specId, toolIdx) + '_' + Date.now(),
        type: type, toolName: tool.name, specialtyName: spec ? spec.name : specId,
        certLabel: cfg.label, ts: Date.now(), status: 'pending'
    };
    try {
        var all = JSON.parse(localStorage.getItem(C.REQUESTS_KEY) || '[]');
        all.push(req);
        localStorage.setItem(C.REQUESTS_KEY, JSON.stringify(all));
    } catch (e) {}
    if (window._AUS_BUS) window._AUS_BUS.emit('XP_AWARDED', { amount: 20, source: 'cert_request' });
    var msgEl = document.getElementById('certRequestMsg');
    if (msgEl) {
        msgEl.innerHTML = '<div class="cert-request-confirm"><i class="fas fa-check-circle"></i> تم تسجيل طلبك. توجّه إلى قسم <b>الابتكار (الريادة والابتكار)</b> لإكمال إجراءات إصدار الشهادة الرسمية.' +
            ' <button class="cert-link-btn" onclick="showSection(\'innovation\');innOpen&&innOpen()">فتح القسم ←</button></div>';
    }
    if (typeof showToast === 'function') showToast('✅ تم تسجيل طلب الشهادة', 'xp-toast');
};

window._certPrintResult = function (type, specId, toolIdx) {
    var tool = C.getTool(specId, toolIdx);
    var spec = C.getSpecialty(specId);
    var cfg = C.CERT_CONFIG[type];
    var results = C.getResults();
    var result = results[C.certId(type, specId, toolIdx)];
    if (!result) return;
    var d = new Date(result.ts);
    var dateStr = d.toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' });
    var win = window.open('', '_blank');
    if (!win) { if (typeof showToast === 'function') showToast('يرجى السماح بالنوافذ المنبثقة للطباعة', 'heart-toast'); return; }
    win.document.write(
        '<html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>نتيجة ' + cfg.label + '</title><style>' +
        'body{font-family:"Tajawal",Arial,sans-serif;background:#fff;color:#111;padding:60px;text-align:center;}' +
        '.cert-print{border:10px double #d4af37;padding:60px 40px;max-width:720px;margin:0 auto;}' +
        'h1{color:#8a6d00;font-size:1.6rem;margin-bottom:6px;} h2{font-size:2rem;margin:18px 0;}' +
        '.seal{font-size:3rem;margin-bottom:10px;} .name-line{font-size:1.3rem;font-weight:700;margin:24px 0 4px;border-bottom:2px solid #d4af37;display:inline-block;padding-bottom:6px;}' +
        '.meta{color:#555;font-size:0.95rem;margin-top:30px;line-height:1.9;} .pct{font-size:2.6rem;font-weight:900;color:#8a6d00;margin:14px 0;}' +
        '@media print { body{padding:0;} }' +
        '</style></head><body>' +
        '<div class="cert-print">' +
            '<div class="seal">🏅</div>' +
            '<h1>AUS — AI University Simulator</h1>' +
            '<h2>' + cfg.icon + ' ' + cfg.label + '</h2>' +
            '<p>نتيجة اختبار: <b>' + tool.name + '</b> — ' + (spec ? spec.name : '') + '</p>' +
            '<div class="pct">' + result.percent + '%</div>' +
            '<p>' + result.correct + ' إجابة صحيحة من أصل ' + result.total + '</p>' +
            '<div class="meta">تاريخ الإنجاز: ' + dateStr + '<br>' +
            'هذه وثيقة نتيجة داخلية — لإصدار الشهادة الرسمية يُرجى مراجعة قسم الريادة والابتكار داخل المنصة.</div>' +
        '</div>' +
        '<script>window.onload=function(){window.print();}<\/script>' +
        '</body></html>'
    );
    win.document.close();
};

// =============================================================================
// PAYMENT GATE — 5 JOD (Knowledge) / 10 JOD (Practical), PayPal + manual CliQ/IBAN
// Mirrors the UX already established in aus_05_paywall.js, kept as an
// independent modal so it never collides with the existing file-purchase flow.
// =============================================================================
var _certPaySuccessCb = null;
var _certPayCtx = null;

function _closeCertPayment() {
    var bd = document.getElementById('cert-pay-backdrop');
    if (bd) bd.classList.remove('show');
}

window.openCertPayment = function (type, specId, toolIdx, onSuccess) {
    var tool = C.getTool(specId, toolIdx);
    var cfg = C.CERT_CONFIG[type];
    _certPaySuccessCb = onSuccess;
    _certPayCtx = { type: type, specId: specId, toolIdx: toolIdx };

    if (!document.getElementById('cert-pay-backdrop')) {
        var bd = document.createElement('div');
        bd.id = 'cert-pay-backdrop';
        bd.className = 'cert-pay-backdrop';
        bd.innerHTML = '<div id="cert-pay-modal" class="cert-pay-modal"></div>';
        document.body.appendChild(bd);
        bd.addEventListener('click', function (e) { if (e.target === bd) _closeCertPayment(); });
    }
    var merchant = (typeof _MERCHANT !== 'undefined') ? _MERCHANT : {};
    var modal = document.getElementById('cert-pay-modal');
    modal.innerHTML =
    '<button class="cert-pay-close" onclick="window._closeCertPaymentModal()">✕</button>' +
    '<div class="cert-pay-head">' +
        '<div class="cert-pay-icon">' + cfg.icon + '</div>' +
        '<h3>' + cfg.label + ' — ' + tool.name + '</h3>' +
        '<div class="cert-pay-price">' + cfg.price + ' <span>د.أ JOD</span></div>' +
    '</div>' +
    '<div class="cert-pay-body">' +
        '<input type="text" id="certPayName" class="cert-pay-input" placeholder="الاسم الكامل (للتحقق)" autocomplete="name" />' +
        '<div id="paypal-cert-button-container" style="margin-top:14px;min-height:45px;"></div>' +
        '<div class="cert-pay-divider"><span>أو الدفع اليدوي</span></div>' +
        (merchant.cliqAlias ? '<div class="cert-pay-manual-row"><span>CliQ: <b>' + merchant.cliqAlias + '</b></span></div>' : '') +
        (merchant.iban ? '<div class="cert-pay-manual-row"><span>IBAN: <b style="direction:ltr;display:inline-block">' + merchant.iban + '</b></span></div>' : '') +
        '<button class="cert-btn-gold" style="width:100%;margin-top:14px;" id="certManualConfirm" onclick="window._confirmCertManualPayment()">' +
            '<i class="fas fa-check"></i> أكّدت التحويل — تفعيل الشهادة' +
        '</button>' +
    '</div>';
    document.getElementById('cert-pay-backdrop').classList.add('show');
    _mountCertPayPalButton(tool, cfg);
};
window._closeCertPaymentModal = _closeCertPayment;

function _mountCertPayPalButton(tool, cfg) {
    var container = document.getElementById('paypal-cert-button-container');
    if (!container || typeof paypal === 'undefined' || !paypal.Buttons) return;
    var usdAmount = (cfg.price * 1.41).toFixed(2);
    try {
        paypal.Buttons({
            style: { shape: 'rect', color: 'gold', layout: 'vertical', label: 'paypal', height: 42 },
            createOrder: function (data, actions) {
                var name = document.getElementById('certPayName');
                if (name && name.value.trim().length < 3) {
                    if (typeof showToast === 'function') showToast('الرجاء إدخال اسمك الكامل قبل الدفع', 'heart-toast');
                    return null;
                }
                return actions.order.create({ purchase_units: [{ description: cfg.label + ' — ' + tool.name, amount: { currency_code: 'USD', value: usdAmount } }] });
            },
            onApprove: function (data, actions) {
                return actions.order.capture().then(function () { _certPaymentSucceeded(); });
            },
            onError: function () { if (typeof showToast === 'function') showToast('حدث خطأ أثناء الدفع — حاول مجدداً', 'heart-toast'); },
            onCancel: function () { if (typeof showToast === 'function') showToast('تم إلغاء الدفع', 'heart-toast'); }
        }).render('#paypal-cert-button-container');
    } catch (e) { /* PayPal SDK unavailable — manual path below still works */ }
}

window._confirmCertManualPayment = function () {
    var name = document.getElementById('certPayName');
    if (!name || name.value.trim().length < 3) {
        if (typeof showToast === 'function') showToast('الرجاء إدخال اسمك الكامل للتحقق', 'heart-toast');
        return;
    }
    var btn = document.getElementById('certManualConfirm');
    if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جارٍ التفعيل...'; }
    setTimeout(_certPaymentSucceeded, 1200);
};

function _certPaymentSucceeded() {
    if (!_certPayCtx) return;
    var id = C.certId(_certPayCtx.type, _certPayCtx.specId, _certPayCtx.toolIdx);
    C.markCertPurchased(id);
    if (typeof sfxPlay === 'function') sfxPlay('level');
    if (typeof showToast === 'function') showToast('✅ تم الدفع بنجاح — الشهادة مفعّلة', 'xp-toast');
    _closeCertPayment();
    var cb = _certPaySuccessCb;
    _certPaySuccessCb = null;
    if (cb) cb();
}

// =============================================================================
// RICH PRE-EXAM LEARN PAGE — reuses tool.learn + synthesized sections + AI button
// =============================================================================
function _synthWhenNot(tool) {
    return 'تجنّب الاعتماد على "' + tool.name + '" عندما يكون الموقف بعيداً عن سياقها الطبيعي — أي حين لا ينطبق الوصف التالي: «' + tool.learn.useCase + '». في تلك الحالات، الاعتماد الأعمى على الأداة قد يُنتج قرارات مضلَّلة بدلاً من حلول حقيقية.';
}
function _synthBestPractices(tool) {
    var arr = tool.learn.benefits.map(function (b) { return 'استثمر في: ' + b; });
    arr.push('راجع النتائج دورياً لتفادي الوقوع في: ' + tool.learn.pitfall);
    return arr;
}
function _synthComparison(tool, siblings) {
    var others = siblings.slice(0, 3);
    if (!others.length) return 'لا توجد أدوات أخرى ضمن نفس التخصص للمقارنة حالياً.';
    return others.map(function (t) { return '<b>' + t.name + '</b>: ' + t.desc; }).join('<br>');
}
function _aiExtraCacheKey(specId, toolIdx) { return C.AI_CACHE_KEY_PREFIX + specId + '_' + toolIdx; }

window.openCertLearnPage = function (type, specId, toolIdx) {
    var host = _certHost();
    if (!host) return;
    var tool = C.getTool(specId, toolIdx);
    var siblings = C.getSiblingTools(specId, toolIdx);
    var cfg = C.CERT_CONFIG[type];
    var certificateId = C.certId(type, specId, toolIdx);
    var purchased = C.isCertPurchased(certificateId);
    var cachedExtra = null;
    try { cachedExtra = localStorage.getItem(_aiExtraCacheKey(specId, toolIdx)); } catch (e) {}

    host.innerHTML =
    '<div class="cert-wrap">' +
        '<button class="cert-back-btn" onclick="window.openCertifications(\'' + specId + '\',' + toolIdx + ')"><i class="fas fa-arrow-right"></i> رجوع للشهادات</button>' +
        '<div class="cert-card cert-learn">' +
            '<div class="cert-learn-head">' +
                '<div class="cert-learn-icon">' + tool.icon + '</div>' +
                '<div><h2>' + tool.name + '</h2><span class="cert-learn-badge">' + cfg.icon + ' التحضير لـ ' + cfg.label + '</span></div>' +
            '</div>' +
            _certSection('fa-book', 'ما هي "' + tool.name + '"؟', '<p>' + tool.learn.intro + '</p>') +
            _certSection('fa-key', 'المكونات والمفاهيم الأساسية', '<ul>' + tool.learn.points.map(function (p) { return '<li>' + p + '</li>'; }).join('') + '</ul>') +
            _certSection('fa-bullseye', 'متى تُستخدم؟', '<p>' + tool.learn.useCase + '</p>') +
            _certSection('fa-ban', 'متى لا تُستخدم؟', '<p>' + _synthWhenNot(tool) + '</p>') +
            _certSection('fa-gem', 'المزايا', '<ul>' + tool.learn.benefits.map(function (b) { return '<li>' + b + '</li>'; }).join('') + '</ul>') +
            _certSection('fa-lightbulb', 'أفضل الممارسات', '<ul>' + _synthBestPractices(tool).map(function (b) { return '<li>' + b + '</li>'; }).join('') + '</ul>') +
            _certSection('fa-exclamation-triangle', 'الأخطاء الشائعة', '<p>' + tool.learn.pitfall + '</p>') +
            _certSection('fa-building', 'مثال ودراسة حالة واقعية', '<p>' + tool.learn.example + '</p>') +
            _certSection('fa-balance-scale', 'مقارنة مع أدوات أخرى في نفس التخصص', '<p>' + _synthComparison(tool, siblings) + '</p>') +
            '<div class="cert-ai-extra-box">' +
                '<button class="cert-ai-btn" onclick="window._certAskAIExtra(this,\'' + specId + '\',' + toolIdx + ')"><i class="fas fa-robot"></i> اطلب أسرار الخبراء ونصائح احترافية إضافية بالذكاء الاصطناعي</button>' +
                '<div id="certAiExtraOut" class="cert-ai-extra-out" style="display:' + (cachedExtra ? 'block' : 'none') + '">' + (cachedExtra ? C.sanitize(cachedExtra) : '') + '</div>' +
            '</div>' +
            '<button class="cert-start-exam-btn" onclick="window._certGateAndStart(\'' + type + '\',\'' + specId + '\',' + toolIdx + ')">' +
                '<i class="fas fa-play"></i> ' + (purchased ? 'ابدأ الامتحان' : 'التقديم — ' + cfg.price + ' د.أ') + ' (' + cfg.questions + ' سؤال · ' + cfg.seconds + ' ثانية/سؤال)' +
            '</button>' +
        '</div>' +
    '</div>';
    host.scrollIntoView({ behavior: 'smooth', block: 'start' });
};

function _certSection(icon, title, bodyHtml) {
    return '<section class="cert-learn-section"><h3><i class="fas ' + icon + '"></i> ' + title + '</h3>' + bodyHtml + '</section>';
}

window._certAskAIExtra = function (btn, specId, toolIdx) {
    var tool = C.getTool(specId, toolIdx);
    var out = document.getElementById('certAiExtraOut');
    if (!window._AUS_AI || typeof window._AUS_AI.ask !== 'function') {
        if (out) { out.style.display = 'block'; out.textContent = 'الميزة غير متاحة حالياً — الخادم غير متصل.'; }
        return;
    }
    if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جارٍ التحضير...'; }
    window._AUS_AI.ask('certification',
        'اذكر 3 أسرار احترافية يستخدمها الخبراء عند تطبيق أداة "' + tool.name + '" في بيئة عمل حقيقية، ومثالاً واحداً إضافياً من سوق العمل، وأهم اختصار أو إعداد عملي متقدم. كن مختصراً ومباشراً (لا تتجاوز 6 أسطر).',
        'أنت مستشار إداري خبير يقدم نصائح عملية دقيقة ومختصرة.',
        function (err, text) {
            if (btn) btn.style.display = 'none';
            if (!out) return;
            out.style.display = 'block';
            out.innerHTML = err ? 'تعذر الحصول على رد الآن.' : C.sanitize(text);
            if (!err) { try { localStorage.setItem(_aiExtraCacheKey(specId, toolIdx), text); } catch (e) {} }
        }
    );
};

window._certGateAndStart = function (type, specId, toolIdx) {
    var id = C.certId(type, specId, toolIdx);
    if (C.isCertPurchased(id)) { startExam(type, specId, toolIdx); return; }
    window.openCertPayment(type, specId, toolIdx, function () { startExam(type, specId, toolIdx); });
};

// =============================================================================
// CERTIFICATIONS HUB — entry point injected into every tool automatically
// =============================================================================
window.openCertifications = function (specId, toolIdx) {
    var host = document.getElementById('toolQuizArea');
    if (!host) return;
    if (!document.getElementById('certHost')) {
        var div = document.createElement('div');
        div.id = 'certHost';
        host.appendChild(div);
    }
    var certHost = document.getElementById('certHost');
    var tool = C.getTool(specId, toolIdx);
    var results = C.getResults();
    var kId = C.certId('knowledge', specId, toolIdx);
    var pId = C.certId('practical', specId, toolIdx);
    var kResult = results[kId];
    var pResult = results[pId];

    function cardHtml(type, result) {
        var cfg = C.CERT_CONFIG[type];
        var statusHtml = result
            ? (result.passed ? '<span class="cert-status pass"><i class="fas fa-check-circle"></i> ناجح — ' + result.percent + '%</span>' : '<span class="cert-status fail"><i class="fas fa-times-circle"></i> لم يُجتز — ' + result.percent + '%</span>')
            : '<span class="cert-status new">جديد</span>';
        return '' +
        '<div class="cert-track-card" onclick="window.openCertLearnPage(\'' + type + '\',\'' + specId + '\',' + toolIdx + ')">' +
            '<div class="cert-track-icon">' + cfg.icon + '</div>' +
            '<h4>' + cfg.label + '</h4>' +
            '<div class="cert-track-meta">' + cfg.questions + ' سؤال · ' + cfg.seconds + ' ث/سؤال · نجاح ' + cfg.passPercent + '%</div>' +
            '<div class="cert-track-price">' + cfg.price + ' د.أ</div>' +
            statusHtml +
        '</div>';
    }

    certHost.innerHTML =
    '<div class="cert-wrap">' +
        '<div class="cert-hub-head">' +
            '<h3><i class="fas fa-award"></i> الشهادات الاحترافية — ' + tool.name + '</h3>' +
            '<p>أثبت إتقانك لهذه الأداة عبر شهادتين معتمدتين رسمياً من المنصة</p>' +
        '</div>' +
        '<div class="cert-tracks-grid">' + cardHtml('knowledge', kResult) + cardHtml('practical', pResult) + '</div>' +
    '</div>';
    certHost.scrollIntoView({ behavior: 'smooth', block: 'start' });
};

// =============================================================================
// STYLES — professional certification look, gold/dark theme (matches platform)
// =============================================================================
function _addCertStyles() {
    if (document.getElementById('cert-styles')) return;
    var s = document.createElement('style');
    s.id = 'cert-styles';
    s.textContent = [
        '.cert-wrap{max-width:900px;margin:20px auto;padding:0 16px;font-family:"Tajawal",sans-serif;}',
        '.cert-card{background:rgba(0,12,30,0.6);border:1px solid rgba(212,175,55,0.25);border-radius:20px;padding:32px;backdrop-filter:blur(16px);box-shadow:0 20px 50px rgba(0,0,0,0.4);}',
        '.cert-back-btn{background:none;border:1px solid rgba(212,175,55,0.3);color:#d4af37;padding:6px 16px;border-radius:20px;cursor:pointer;font-family:inherit;font-size:0.82rem;margin-bottom:16px;}',
        '.cert-back-btn:hover{background:rgba(212,175,55,0.1);}',
        // Hub
        '.cert-hub-head{text-align:center;margin-bottom:22px;}',
        '.cert-hub-head h3{color:#d4af37;font-size:1.4rem;margin:0 0 6px;text-shadow:0 0 20px rgba(212,175,55,0.3);}',
        '.cert-hub-head p{color:rgba(255,255,255,0.5);font-size:0.85rem;margin:0;}',
        '.cert-tracks-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:18px;}',
        '.cert-track-card{background:rgba(0,12,30,0.55);border:1px solid rgba(212,175,55,0.22);border-radius:18px;padding:24px;text-align:center;cursor:pointer;transition:all .25s;}',
        '.cert-track-card:hover{transform:translateY(-4px);border-color:rgba(212,175,55,0.55);box-shadow:0 12px 32px rgba(212,175,55,0.15);}',
        '.cert-track-icon{font-size:2.2rem;margin-bottom:8px;}',
        '.cert-track-card h4{color:#fff;margin:0 0 8px;font-size:1.05rem;}',
        '.cert-track-meta{color:rgba(255,255,255,0.45);font-size:0.75rem;margin-bottom:10px;}',
        '.cert-track-price{color:#d4af37;font-weight:800;font-size:1.2rem;margin-bottom:10px;}',
        '.cert-status{display:inline-block;font-size:0.72rem;padding:3px 12px;border-radius:12px;background:rgba(255,255,255,0.06);color:rgba(255,255,255,0.5);}',
        '.cert-status.pass{background:rgba(0,245,160,0.12);color:#00f5a0;}',
        '.cert-status.fail{background:rgba(255,70,70,0.12);color:#ff8080;}',
        // Learn page
        '.cert-learn-head{display:flex;align-items:center;gap:16px;margin-bottom:22px;padding-bottom:18px;border-bottom:1px solid rgba(255,255,255,0.08);}',
        '.cert-learn-icon{font-size:2.4rem;}',
        '.cert-learn-head h2{color:#fff;margin:0 0 4px;font-size:1.3rem;}',
        '.cert-learn-badge{display:inline-block;background:rgba(212,175,55,0.12);border:1px solid rgba(212,175,55,0.3);color:#d4af37;padding:2px 12px;border-radius:12px;font-size:0.72rem;}',
        '.cert-learn-section{margin-bottom:20px;}',
        '.cert-learn-section h3{color:#00d4ff;font-size:0.95rem;display:flex;align-items:center;gap:8px;margin-bottom:8px;}',
        '.cert-learn-section p, .cert-learn-section ul{color:rgba(255,255,255,0.68);font-size:0.88rem;line-height:1.8;margin:0;padding-inline-start:20px;}',
        '.cert-ai-extra-box{background:rgba(123,47,255,0.05);border:1px solid rgba(123,47,255,0.2);border-radius:14px;padding:16px;margin:20px 0;text-align:center;}',
        '.cert-ai-btn{background:rgba(123,47,255,0.12);border:1px solid rgba(123,47,255,0.35);color:#c084fc;padding:9px 20px;border-radius:20px;cursor:pointer;font-family:inherit;font-size:0.82rem;}',
        '.cert-ai-btn:hover{background:rgba(123,47,255,0.2);}',
        '.cert-ai-extra-out{margin-top:12px;color:rgba(255,255,255,0.72);font-size:0.85rem;line-height:1.8;text-align:right;}',
        '.cert-start-exam-btn{display:block;width:100%;margin-top:10px;background:linear-gradient(135deg,#d4af37,#f4d675);color:#0a0812;border:none;font-weight:800;padding:16px;border-radius:16px;cursor:pointer;font-family:inherit;font-size:1rem;box-shadow:0 10px 28px rgba(212,175,55,0.3);}',
        '.cert-start-exam-btn:hover{transform:translateY(-2px);}',
        // Exam
        '.cert-exam-top{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;}',
        '.cert-exam-badge{color:#d4af37;font-size:0.85rem;font-weight:700;}',
        '.cert-exam-count{color:rgba(255,255,255,0.5);font-size:0.8rem;}',
        '.cert-progress-track{height:5px;border-radius:3px;background:rgba(255,255,255,0.08);overflow:hidden;margin-bottom:16px;}',
        '.cert-progress-track i{display:block;height:100%;background:linear-gradient(90deg,#d4af37,#00d4ff);}',
        '.cert-timer-row{display:flex;align-items:center;gap:12px;margin-bottom:16px;}',
        '.cert-timer-ring{width:44px;height:44px;border-radius:50%;border:3px solid rgba(0,212,255,0.4);display:flex;align-items:center;justify-content:center;color:#00d4ff;font-weight:800;flex-shrink:0;}',
        '.cert-timer-ring.urgent{border-color:#ff4646;color:#ff4646;animation:certPulse .6s infinite;}',
        '@keyframes certPulse{0%,100%{opacity:1;}50%{opacity:.5;}}',
        '.cert-timer-bar-track{flex:1;height:6px;border-radius:3px;background:rgba(255,255,255,0.08);overflow:hidden;}',
        '.cert-timer-bar-track i{display:block;height:100%;background:linear-gradient(90deg,#00d4ff,#d4af37);transition:width .2s linear;}',
        '.cert-q-prompt{color:#fff;font-size:1.05rem;line-height:1.7;margin-bottom:20px;font-weight:600;}',
        '.cert-hint{color:rgba(255,255,255,0.4);font-size:0.78rem;margin-bottom:14px;}',
        '.cert-q-opts{display:flex;flex-direction:column;gap:10px;}',
        '.cert-opt{display:flex;align-items:center;gap:12px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.12);color:#fff;padding:14px 16px;border-radius:12px;cursor:pointer;font-family:inherit;font-size:0.9rem;text-align:right;transition:all .15s;}',
        '.cert-opt:hover{border-color:rgba(0,212,255,0.4);background:rgba(0,212,255,0.06);}',
        '.cert-opt-badge{width:26px;height:26px;border-radius:50%;background:rgba(212,175,55,0.15);border:1px solid rgba(212,175,55,0.35);color:#d4af37;display:flex;align-items:center;justify-content:center;font-size:0.75rem;font-weight:800;flex-shrink:0;}',
        '.cert-order-list{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:20px;}',
        '.cert-order-chip{background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.15);color:#fff;padding:10px 16px;border-radius:20px;cursor:pointer;font-family:inherit;font-size:0.85rem;display:flex;align-items:center;gap:8px;}',
        '.cert-order-chip.picked{background:rgba(0,212,255,0.12);border-color:#00d4ff;}',
        '.cert-order-num{width:20px;height:20px;border-radius:50%;background:#00d4ff;color:#000;display:flex;align-items:center;justify-content:center;font-size:0.68rem;font-weight:800;}',
        '.cert-match-cols{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:20px;}',
        '.cert-match-col{display:flex;flex-direction:column;gap:8px;}',
        '.cert-match-item{background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.15);color:#fff;padding:10px 14px;border-radius:10px;cursor:pointer;font-family:inherit;font-size:0.82rem;text-align:right;}',
        '.cert-match-item.selected{border-color:#00d4ff;background:rgba(0,212,255,0.1);}',
        '.cert-match-item.matched{opacity:0.5;cursor:default;}',
        '.cert-submit-btn{display:block;width:100%;background:#d4af37;color:#0a0812;border:none;padding:13px;border-radius:14px;cursor:pointer;font-weight:800;font-family:inherit;}',
        '.cert-submit-btn:disabled{opacity:0.35;cursor:not-allowed;}',
        // Results
        '.cert-result{text-align:center;}',
        '.cert-result.pass{border-color:rgba(0,245,160,0.35);}',
        '.cert-result.fail{border-color:rgba(255,100,100,0.3);}',
        '.cert-result-icon{font-size:3.4rem;margin-bottom:6px;}',
        '.cert-result-pct{font-size:3rem;font-weight:900;color:#d4af37;}',
        '.cert-result-title{color:#fff;font-size:1.2rem;margin:8px 0;}',
        '.cert-result-sub{color:rgba(255,255,255,0.55);font-size:0.9rem;}',
        '.cert-result-detail{color:rgba(255,255,255,0.4);font-size:0.8rem;margin-top:4px;}',
        '.cert-official-box{background:rgba(212,175,55,0.06);border:2px double rgba(212,175,55,0.35);border-radius:14px;padding:18px;margin:22px 0;display:flex;align-items:center;gap:14px;text-align:right;}',
        '.cert-official-box i{font-size:1.8rem;color:#d4af37;flex-shrink:0;}',
        '.cert-official-box p{color:rgba(255,255,255,0.75);font-size:0.88rem;line-height:1.8;margin:0;}',
        '.cert-result-actions{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:18px;}',
        '.cert-btn-gold{background:linear-gradient(135deg,#d4af37,#f4d675);color:#0a0812;border:none;padding:12px 24px;border-radius:20px;cursor:pointer;font-weight:800;font-family:inherit;font-size:0.88rem;}',
        '.cert-btn-outline{background:none;border:1px solid rgba(0,212,255,0.4);color:#00d4ff;padding:12px 24px;border-radius:20px;cursor:pointer;font-family:inherit;font-size:0.88rem;}',
        '.cert-btn-ghost{background:none;border:1px solid rgba(255,255,255,0.15);color:rgba(255,255,255,0.6);padding:12px 24px;border-radius:20px;cursor:pointer;font-family:inherit;font-size:0.88rem;}',
        '.cert-request-confirm{margin-top:16px;background:rgba(0,245,160,0.08);border:1px solid rgba(0,245,160,0.25);border-radius:12px;padding:14px;color:rgba(255,255,255,0.75);font-size:0.85rem;line-height:1.7;}',
        '.cert-request-confirm i{color:#00f5a0;margin-left:6px;}',
        '.cert-link-btn{background:rgba(0,212,255,0.12);border:1px solid rgba(0,212,255,0.35);color:#00d4ff;border-radius:14px;padding:4px 14px;cursor:pointer;font-family:inherit;font-size:0.78rem;margin-right:8px;}',
        '.cert-spin{font-size:2.4rem;color:#d4af37;}',
        // Payment modal
        '.cert-pay-backdrop{position:fixed;inset:0;background:rgba(0,4,12,0.75);z-index:16000;display:none;align-items:center;justify-content:center;padding:20px;backdrop-filter:blur(6px);}',
        '.cert-pay-backdrop.show{display:flex;}',
        '.cert-pay-modal{position:relative;max-width:420px;width:100%;background:rgba(6,4,18,0.95);border:1px solid rgba(212,175,55,0.3);border-radius:20px;padding:28px;font-family:"Tajawal",sans-serif;}',
        '.cert-pay-close{position:absolute;top:14px;left:14px;background:rgba(255,255,255,0.08);border:none;color:#fff;width:30px;height:30px;border-radius:50%;cursor:pointer;}',
        '.cert-pay-head{text-align:center;margin-bottom:18px;}',
        '.cert-pay-icon{font-size:2rem;}',
        '.cert-pay-head h3{color:#fff;font-size:1.05rem;margin:6px 0;}',
        '.cert-pay-price{color:#d4af37;font-size:1.8rem;font-weight:900;}',
        '.cert-pay-price span{font-size:0.9rem;color:rgba(255,255,255,0.5);}',
        '.cert-pay-input{width:100%;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.15);color:#fff;padding:12px 14px;border-radius:12px;font-family:inherit;font-size:0.9rem;box-sizing:border-box;}',
        '.cert-pay-divider{text-align:center;color:rgba(255,255,255,0.35);font-size:0.75rem;margin:16px 0;position:relative;}',
        '.cert-pay-manual-row{background:rgba(255,255,255,0.04);border-radius:10px;padding:10px 14px;margin-bottom:8px;color:rgba(255,255,255,0.7);font-size:0.82rem;}'
    ].join('\n');
    document.head.appendChild(s);
}
_addCertStyles();

if (window._AUS_REGISTRY) {
    window._AUS_REGISTRY.register('certification', { open: window.openCertifications }, {
        name: 'Professional Certifications', icon: '🎓', defaultEnabled: true
    });
}

window._AUS_CERT_EXAM = { startExam: startExam, scoreAttempt: scoreAttempt, loadAttempt: loadAttempt };

})();
