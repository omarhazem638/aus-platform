// =============================================================================
// aus_36_certification.js  —  Professional Certification System
// Attaches automatically to every tool across all 7 specialties (70 tools).
// Two tracks: Knowledge Certificate (5 JOD · 25 Q · 20s/Q) and
//             Practical Certificate (10 JOD · 40 Q · 20s/Q)
// Question generation: template-based (offline, always works) + AI-enhanced
// via window._AUS_AI.askJSON when the backend is reachable.
// =============================================================================

(function () {
'use strict';

// ── Config ───────────────────────────────────────────────────────────────────
var CERT_CONFIG = {
    knowledge: {
        price: 5, questions: 25, seconds: 20, passPercent: 80,
        label: 'شهادة المعرفة', labelEn: 'Knowledge Certificate', icon: '📘',
        passMsg: '🎉 تهانينا، لقد اجتزت اختبار شهادة المعرفة بنجاح.',
        failMsg: 'حظاً أوفر. يمكنك إعادة المحاولة بعد مراجعة المحتوى التعليمي.'
    },
    practical: {
        price: 10, questions: 40, seconds: 20, passPercent: 80,
        label: 'شهادة الممارسة', labelEn: 'Practical Certificate', icon: '🏆',
        passMsg: '🎉 تهانينا، لقد اجتزت شهادة الممارسة.',
        failMsg: 'حظاً أوفر. يمكنك إعادة المحاولة لاحقاً.'
    }
};

var PURCHASED_KEY = 'aus.cert.purchased';
var ATTEMPT_KEY_PREFIX = 'aus.cert.attempt.';
var RESULTS_KEY = 'aus.cert.results';
var REQUESTS_KEY = 'aus.cert.requests';
var AI_CACHE_KEY_PREFIX = 'aus.cert.aiExtra.';

function certId(type, specId, toolIdx) { return type + '_' + specId + '_' + toolIdx; }

function getPurchased() { try { return JSON.parse(localStorage.getItem(PURCHASED_KEY) || '[]'); } catch (e) { return []; } }
function isCertPurchased(id) { return getPurchased().indexOf(id) !== -1; }
function markCertPurchased(id) {
    var list = getPurchased();
    if (list.indexOf(id) === -1) { list.push(id); try { localStorage.setItem(PURCHASED_KEY, JSON.stringify(list)); } catch (e) {} }
}

function getResults() { try { return JSON.parse(localStorage.getItem(RESULTS_KEY) || '{}'); } catch (e) { return {}; } }
function saveResult(id, result) {
    var all = getResults();
    all[id] = result;
    try { localStorage.setItem(RESULTS_KEY, JSON.stringify(all)); } catch (e) {}
}

function getTool(specId, toolIdx) {
    var tools = (typeof toolsData !== 'undefined' && toolsData[specId]) || [];
    return tools[toolIdx];
}
function getSpecialty(specId) {
    return (typeof specialties !== 'undefined' ? specialties : []).find(function (s) { return s.id === specId; });
}
function getSiblingTools(specId, excludeIdx) {
    var tools = (typeof toolsData !== 'undefined' && toolsData[specId]) || [];
    return tools.filter(function (t, i) { return i !== excludeIdx; });
}

// ── Small local utilities (self-contained — do not rely on private helpers
//    defined inside other files' closures) ──────────────────────────────────
function shuffle(arr) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
}
function pick(arr, n) { return shuffle(arr).slice(0, n); }
function sanitize(str) {
    if (window._AUS_UTILS && typeof window._AUS_UTILS.sanitize === 'function') return window._AUS_UTILS.sanitize(str);
    return String(str || '').replace(/[<>"'`&]/g, function (c) {
        return { '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;', '`': '&#96;', '&': '&amp;' }[c];
    });
}
// Splits a "Term — Definition" style point string used throughout toolsData.
function parsePointPair(pointStr, fallbackTerm) {
    var idx = pointStr.indexOf('—');
    if (idx === -1) idx = pointStr.indexOf('-');
    if (idx > 0 && idx < pointStr.length - 1) {
        return { term: pointStr.slice(0, idx).trim(), def: pointStr.slice(idx + 1).trim() };
    }
    return { term: fallbackTerm || pointStr.slice(0, 18), def: pointStr };
}

// Generic anti-pattern statements — plausible-sounding but wrong distractors,
// reused across both certificate tracks (mirrors the pattern already proven
// in aus_01_data.js's generateToolQuestions, expanded for exam-scale volume).
var WRONG_POOL = [
    'يعتمد كلياً على الحدس الشخصي ويتجاهل البيانات والتحليل الموضوعي',
    'يضيف طبقات معقّدة من الإجراءات البيروقراطية دون قيمة عملية حقيقية',
    'يقطع قنوات التواصل بين الأقسام ويعزل كل فريق على حدة',
    'يركّز على كمية المخرجات السريعة على حساب جودتها وأثرها الفعلي',
    'يقلّل من المساءلة ويترك النتائج دون قياس أو متابعة منتظمة',
    'يحصر كل سلطة اتخاذ القرار في شخص واحد دون تفويض أو مشاركة',
    'يؤجّل القرارات الحاسمة لأجل غير مسمّى انتظاراً لظروف مثالية',
    'يتجنّب الاستثمار في تدريب الفريق ويعتمد على المهارات الحالية فقط',
    'يلغي التقييم المستمر للأداء ويكتفي بمراجعة سنوية واحدة شاملة',
    'يفرض نظاماً صارماً جامداً دون أي مرونة أو مراجعة دورية للتحسين',
    'يستجيب متأخراً لتغيّرات السوق بعد أن يفوت أوان المعالجة المناسبة',
    'يخفي المعلومات الحرجة عن الفريق ويشاركها فقط عند وقوع الأزمات',
    'يستبعد الإدارة العليا من القرار ويتجاوز التسلسل الإداري المعتمد',
    'يطبّق حلولاً جاهزة منسوخة دون فهم جذور المشكلة وسياقها الخاص',
    'يعتمد على تقنية واحدة في كل المواقف دون مراعاة اختلاف الحالات',
    'يبدأ بالتنفيذ الفوري دون تحليل مسبق للمخاطر أو الموارد المتاحة',
    'يعتمد فقط على رأي المدير التنفيذي دون إشراك أصحاب الخبرة الفنية',
    'يقيس النجاح بردود الفعل الفورية بدلاً من الأثر على المدى الطويل',
    'يهمل توثيق القرارات مما يصعّب مراجعتها أو التعلم منها لاحقاً',
    'ينسخ تجربة شركة أخرى حرفياً دون تكييفها مع سياق المؤسسة'
];

// =============================================================================
// QUESTION GENERATORS — Knowledge track (recall + comprehension + reasoning)
// =============================================================================
function qMcqConcept(tool, siblings) {
    var wrongs = pick(siblings.map(function (t) { return t.learn.intro; }).concat(WRONG_POOL), 3);
    return mkMcq('ما هو "' + tool.name + '" باختصار؟', tool.learn.intro, wrongs, tool.learn.intro);
}
function qMcqComponent(tool, siblings) {
    var correct = tool.learn.points[Math.floor(Math.random() * tool.learn.points.length)];
    var siblingPoints = [];
    siblings.forEach(function (t) { siblingPoints = siblingPoints.concat(t.learn.points); });
    var wrongs = pick(siblingPoints, 3);
    return mkMcq('أي مما يلي يُعدّ من المكونات أو المفاهيم الأساسية لـ "' + tool.name + '"؟', correct, wrongs,
        'المكونات الأساسية لـ ' + tool.name + ': ' + tool.learn.points.join(' • '));
}
function qMcqUseCase(tool, siblings) {
    var wrongs = pick(siblings.map(function (t) { return t.learn.useCase; }), 3);
    return mkMcq('متى يكون استخدام "' + tool.name + '" الأكثر فائدة؟', tool.learn.useCase, wrongs, tool.learn.useCase);
}
function qMcqBenefit(tool, siblings) {
    var correct = tool.learn.benefits[Math.floor(Math.random() * tool.learn.benefits.length)];
    var siblingBenefits = [];
    siblings.forEach(function (t) { siblingBenefits = siblingBenefits.concat(t.learn.benefits); });
    var wrongs = pick(siblingBenefits.concat(WRONG_POOL), 3);
    return mkMcq('أي مما يلي يُعدّ فائدة حقيقية من فوائد "' + tool.name + '"؟', correct, wrongs,
        'فوائد ' + tool.name + ': ' + tool.learn.benefits.join(' • '));
}
function qMcqPitfall(tool, siblings) {
    var wrongs = pick(siblings.map(function (t) { return t.learn.pitfall; }).concat(WRONG_POOL), 3);
    return mkMcq('ما أكبر تحدٍ أو خطأ شائع عند تطبيق "' + tool.name + '"؟', tool.learn.pitfall, wrongs, tool.learn.pitfall);
}
function qAnalyticalNegation(tool) {
    var realBenefits = pick(tool.learn.benefits, Math.min(3, tool.learn.benefits.length));
    while (realBenefits.length < 3) realBenefits.push(tool.learn.points[realBenefits.length % tool.learn.points.length]);
    var fake = pick(WRONG_POOL, 1)[0];
    var options = shuffle(realBenefits.concat([fake]));
    return {
        qType: 'mcq',
        prompt: 'أي مما يلي ليس صحيحاً بخصوص "' + tool.name + '"؟',
        options: options,
        correctIndex: options.indexOf(fake),
        explanation: 'كل الخيارات الأخرى تصف فوائد أو مكونات حقيقية لـ ' + tool.name + '، بينما هذا الخيار يصف ممارسة خاطئة لا علاقة لها بالأداة.'
    };
}
function qReasoning(tool, siblings) {
    var otherTool = siblings.length ? siblings[Math.floor(Math.random() * siblings.length)] : null;
    var options = shuffle([
        { t: 'نعم، لأن الموقف يطابق تماماً الحالات التي صُمم لها "' + tool.name + '": ' + tool.learn.useCase, ok: true },
        { t: 'لا، لأن ' + tool.name + ' غير مناسب إطلاقاً لأي قرار استراتيجي', ok: false },
        { t: 'لا فرق، فكل أدوات الإدارة تُعطي نفس النتيجة بغض النظر عن السياق', ok: false },
        { t: otherTool ? ('الأنسب هو استخدام "' + otherTool.name + '" بدلاً منه في كل الحالات') : 'يُفضَّل تجاهل التحليل والاعتماد على الحدس فقط', ok: false }
    ]);
    var correctIdx = options.findIndex(function (o) { return o.ok; });
    return {
        qType: 'mcq',
        prompt: 'فريق يواجه موقفاً يتطلب: "' + tool.learn.useCase + '" — هل يُعدّ "' + tool.name + '" الخيار الصحيح هنا؟ ولماذا؟',
        options: options.map(function (o) { return o.t; }),
        correctIndex: correctIdx,
        explanation: tool.learn.useCase
    };
}
function qOrdering(tool) {
    var items = tool.learn.points.map(function (p) { return parsePointPair(p).term; });
    if (items.length < 3) items = tool.learn.points.slice();
    var order = shuffle(items);
    return {
        qType: 'order',
        prompt: 'رتّب العناصر التالية بالترتيب المعتمد ضمن منهجية "' + tool.name + '":',
        items: order,
        correctOrder: items.slice(),
        explanation: 'الترتيب المعتمد: ' + items.join(' ← ')
    };
}
function qMatching(tool) {
    var pairs = tool.learn.points.map(function (p) { return parsePointPair(p); }).filter(function (p) { return p.term && p.def; });
    if (pairs.length < 3) {
        pairs = [
            { term: tool.name, def: tool.learn.intro },
            { term: 'أفضل استخدام', def: tool.learn.useCase },
            { term: 'أبرز فائدة', def: tool.learn.benefits[0] },
            { term: 'أكبر تحدٍ', def: tool.learn.pitfall }
        ];
    }
    pairs = pairs.slice(0, 4);
    return {
        qType: 'match',
        prompt: 'طابق كل مفهوم ضمن "' + tool.name + '" بتعريفه الصحيح:',
        left: pairs.map(function (p) { return p.term; }),
        right: shuffle(pairs.map(function (p) { return p.def; })),
        correctPairs: pairs.map(function (p) { return p.def; }), // right-side answer aligned to left index
        explanation: pairs.map(function (p) { return p.term + ' = ' + p.def; }).join(' | ')
    };
}
function mkMcq(prompt, correct, wrongs, explanation) {
    while (wrongs.length < 3) wrongs = wrongs.concat(pick(WRONG_POOL, 3 - wrongs.length));
    wrongs = wrongs.slice(0, 3).filter(function (w) { return w !== correct; });
    while (wrongs.length < 3) wrongs.push(pick(WRONG_POOL.filter(function (w) { return w !== correct && wrongs.indexOf(w) === -1; }), 1)[0]);
    var options = shuffle([correct].concat(wrongs));
    return { qType: 'mcq', prompt: prompt, options: options, correctIndex: options.indexOf(correct), explanation: explanation };
}

var KNOWLEDGE_GENERATORS = [qMcqConcept, qMcqComponent, qMcqUseCase, qMcqBenefit, qMcqPitfall, qAnalyticalNegation, qReasoning, qOrdering, qMatching];

// =============================================================================
// QUESTION GENERATORS — Practical track (scenarios, decisions, risk, application)
// =============================================================================
function qScenarioDecision(tool) {
    var correct = 'تطبيق مبدأ "' + parsePointPair(tool.learn.points[0]).term + '" أولاً: ' + tool.learn.useCase;
    var wrongs = pick(WRONG_POOL, 3);
    return mkMcq(
        'أنت مسؤول عن مشروع يعاني من مشكلة تتطلب استخدام "' + tool.name + '". ما هو أفضل إجراء مهني أول؟',
        correct, wrongs, tool.learn.useCase
    );
}
function qRiskAssessment(tool, siblings) {
    var wrongs = pick(siblings.map(function (t) { return t.learn.pitfall; }).concat(WRONG_POOL), 3);
    return mkMcq(
        'ما أكبر خطر يجب الانتباه إليه عند تطبيق "' + tool.name + '" في مشروع حقيقي داخل شركة؟',
        tool.learn.pitfall, wrongs, 'تفادي هذا الخطر يتطلب: ' + tool.learn.benefits[0]
    );
}
function qBestSolution(tool) {
    var point = parsePointPair(tool.learn.points[Math.floor(Math.random() * tool.learn.points.length)]);
    var correct = 'تطبيق "' + point.term + '" بشكل صحيح: ' + point.def;
    var wrongs = pick(WRONG_POOL, 3);
    return mkMcq(
        'بين الخيارات التالية، أي نهج يمثّل التطبيق الاحترافي الصحيح لأحد مبادئ "' + tool.name + '"؟',
        correct, wrongs, point.term + ' — ' + point.def
    );
}
function qCaseAnalysis(tool) {
    var correct = 'الدرس الأهم: ' + tool.learn.benefits[0];
    var wrongs = pick(WRONG_POOL, 3);
    return mkMcq(
        'بناءً على الحالة الواقعية التالية — "' + tool.learn.example + '" — ما الدرس الأهم الذي يجب تطبيقه في شركتك؟',
        correct, wrongs, tool.learn.example
    );
}
function qWorkplaceSimulation(tool) {
    var correct = 'تصحيح المسار عبر: ' + (tool.learn.benefits[1] || tool.learn.benefits[0]);
    var wrongs = pick(WRONG_POOL, 3);
    return mkMcq(
        'فريقك يستخدم "' + tool.name + '" لكنه وقع في هذا الخطأ الشائع: "' + tool.learn.pitfall + '". كخبير محترف، ما الحل الفوري الأنسب؟',
        correct, wrongs, tool.learn.pitfall
    );
}
function qRiskRanking(tool, siblings) {
    var risks = [tool.learn.pitfall].concat(pick(siblings.map(function (t) { return t.learn.pitfall; }), 2));
    // Ordering by "severity for this specific tool's context" — the tool's own pitfall is always most critical here.
    var shuffled = shuffle(risks);
    return {
        qType: 'order',
        prompt: 'رتّب المخاطر التالية حسب الأولوية في الأهمية عند إدارة مشروع يعتمد على "' + tool.name + '" (الأخطر أولاً):',
        items: shuffled,
        correctOrder: risks,
        explanation: 'الأولوية القصوى لتفادي: ' + tool.learn.pitfall
    };
}

var PRACTICAL_GENERATORS = [qScenarioDecision, qRiskAssessment, qBestSolution, qCaseAnalysis, qWorkplaceSimulation, qRiskRanking];

// ── Template-based question builder (offline fallback — always available) ──
function buildTemplateQuestions(tool, siblings, type, count) {
    var pool = (type === 'practical') ? PRACTICAL_GENERATORS : KNOWLEDGE_GENERATORS;
    var out = [];
    var guard = 0;
    while (out.length < count && guard < count * 4) {
        guard++;
        var gen = pool[out.length % pool.length];
        try {
            var q = gen(tool, siblings);
            if (q) out.push(q);
        } catch (e) { /* skip a generator that can't produce a valid question for this tool's data shape */ }
    }
    return shuffle(out).slice(0, count);
}

// ── AI-enhanced question generation (optional layer on top of templates) ────
function buildAIPrompt(tool, type, count) {
    var isPractical = type === 'practical';
    var sys = 'أنت خبير في تصميم امتحانات شهادات مهنية عالمية المستوى. أعد فقط مصفوفة JSON صالحة بدون أي نص إضافي.';
    var schema = '[{"qType":"mcq","prompt":"...","options":["a","b","c","d"],"correctIndex":0,"explanation":"..."}, ...]';
    var user = 'أنشئ ' + count + ' سؤال امتحان ' + (isPractical ? 'عملي متقدم (سيناريوهات واقعية، اتخاذ قرار، تحليل مخاطر، تطبيق عملي — بدون أي سؤال سهل أو يعتمد على الحفظ)' : 'معرفي (فهم وتحليل وتفكير، وليس حفظاً)') +
        ' حول أداة إدارية اسمها "' + tool.name + '".\n' +
        'معلومات الأداة:\n- الشرح: ' + tool.learn.intro + '\n- المكونات: ' + tool.learn.points.join(' | ') +
        '\n- الاستخدام: ' + tool.learn.useCase + '\n- الفوائد: ' + tool.learn.benefits.join(' | ') +
        '\n- مثال واقعي: ' + tool.learn.example + '\n- تحدٍّ شائع: ' + tool.learn.pitfall +
        '\nكل الأسئلة يجب أن ترتبط بهذه الأداة فقط. أعد الناتج بالضبط بهذا الشكل (JSON فقط، كل سؤال qType="mcq" مع 4 خيارات وcorrectIndex):\n' + schema;
    return { sys: sys, user: user };
}
function validateAIQuestions(arr) {
    if (!Array.isArray(arr)) return [];
    return arr.filter(function (q) {
        return q && q.qType === 'mcq' && typeof q.prompt === 'string' && Array.isArray(q.options) &&
               q.options.length >= 2 && typeof q.correctIndex === 'number' &&
               q.correctIndex >= 0 && q.correctIndex < q.options.length;
    }).map(function (q) {
        return { qType: 'mcq', prompt: sanitize(q.prompt), options: q.options.map(sanitize), correctIndex: q.correctIndex, explanation: sanitize(q.explanation || '') };
    });
}

// callback(questions[]) — always resolves, never throws; template fallback guarantees completion.
function generateExamQuestions(tool, siblings, type, count, callback) {
    var templateQs = buildTemplateQuestions(tool, siblings, type, count);
    if (!window._AUS_AI || typeof window._AUS_AI.askJSON !== 'function') { callback(templateQs); return; }

    var p = buildAIPrompt(tool, type, count);
    var settled = false;
    var timeoutId = setTimeout(function () { if (!settled) { settled = true; callback(templateQs); } }, 28000);
    window._AUS_AI.askJSON('certification', p.user, p.sys, function (err, json) {
        if (settled) return;
        clearTimeout(timeoutId);
        settled = true;
        if (err) { callback(templateQs); return; }
        var aiQs = validateAIQuestions(json);
        if (aiQs.length >= Math.floor(count * 0.6)) {
            // Fill any shortfall with template questions so the count always matches exactly.
            var merged = aiQs.slice(0, count);
            if (merged.length < count) merged = merged.concat(templateQs.slice(0, count - merged.length));
            callback(shuffle(merged));
        } else {
            callback(templateQs);
        }
    });
}

// Expose internals needed by the rest of this module (loaded next) via a
// private namespace — kept off `window` except for the one public entry point.
window._AUS_CERT_CORE = {
    CERT_CONFIG: CERT_CONFIG,
    certId: certId, isCertPurchased: isCertPurchased, markCertPurchased: markCertPurchased,
    getResults: getResults, saveResult: saveResult,
    getTool: getTool, getSpecialty: getSpecialty, getSiblingTools: getSiblingTools,
    shuffle: shuffle, pick: pick, sanitize: sanitize, parsePointPair: parsePointPair,
    generateExamQuestions: generateExamQuestions,
    ATTEMPT_KEY_PREFIX: ATTEMPT_KEY_PREFIX, REQUESTS_KEY: REQUESTS_KEY, AI_CACHE_KEY_PREFIX: AI_CACHE_KEY_PREFIX
};

})();
